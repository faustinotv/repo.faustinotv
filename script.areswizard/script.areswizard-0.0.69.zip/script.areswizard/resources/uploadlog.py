import xbmc
xbmc.executebuiltin("RunPlugin(plugin://script.areswizard/?start='uploadlog')", True)